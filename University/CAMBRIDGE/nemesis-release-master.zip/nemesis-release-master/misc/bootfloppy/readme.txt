                         Nemesis boot loader

Press a key within five seconds to interrupt boot. Press F1 for help.

