#include <FSDir.ih>
#include <Exec.ih>

typedef struct {
    FSDir_clp dir;
    Exec_clp  exec;
    CExec_cl  self;
} CExec_st;

