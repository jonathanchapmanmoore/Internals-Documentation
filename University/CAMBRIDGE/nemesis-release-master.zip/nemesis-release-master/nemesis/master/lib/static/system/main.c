/*
*****************************************************************************
**                                                                          *
**  Copyright 1996, University of Cambridge Computer Laboratory             *
**                                                                          *
**  All Rights Reserved (except, who the hell wants them)       	    *
**                                                                          *
*****************************************************************************
**
** FACILITY:	
**
**	Static system library
**
** FUNCTIONAL DESCRIPTION:
**
**	Silly main stub for gcc
**
**
** ID : $Id: main.c 1.1 Thu, 18 Feb 1999 14:16:19 +0000 dr10009 $
**
*/

void __main()
{
}
void __gccmain()
{
}

/* End */
