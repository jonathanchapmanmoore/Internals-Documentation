/* Empty veneer.h for ix86 - use h/$(MC)/veneer_tgt.h instead. */

#include <veneer_tgt.h>
