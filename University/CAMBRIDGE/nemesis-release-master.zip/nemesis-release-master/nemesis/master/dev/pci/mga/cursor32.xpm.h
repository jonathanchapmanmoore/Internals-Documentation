/* XPM */
static char *cursor32_xpm[] = {
/* width height num_colors chars_per_pixel */
"64 64 3 1",
/* colors */
"  c None",
". c white",
"X c black",
/* pixels */
"...                                                             ",
".XX..                                                           ",
".XXXX..                                                         ",
" .XXXXX..                                                       ",
" .XXXXXXX..                                                     ",
"  .XXXXXXXX...                                                  ",
"  .XXXXXXXXXX.                                                  ",
"   .XXXXX.....                                                  ",
"   .XXXXX.                                                      ",
"    .XX..X.                                                     ",
"    .XX. .X.                                                    ",
"     .X.  .X.                                                   ",
"     .X.   .X.                                                  ",
"     ...    .X.                                                 ",
"             .X.                                                ",
"              ..                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
"                                                                ",
};













