/*
 * This file is generated automatically -- DO NOT EDIT
 */

#include "xrip.h"

extern s3VideoChipRec
        MMIO_928,
        S3_GENERIC;

s3VideoChipPtr s3Drivers[] =
{
        &MMIO_928,
        &S3_GENERIC,
        NULL
};
