void gui_control(void);
