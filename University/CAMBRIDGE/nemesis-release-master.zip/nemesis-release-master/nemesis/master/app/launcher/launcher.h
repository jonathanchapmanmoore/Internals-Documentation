#include <nemesis.h>
#include <stdio.h>
#include <stdlib.h>

#include "buttons_gui.h"

typedef struct {
    buttons_gui_st buttons_data;
} launcher_st;
